from logic import *

class FolKB(KB):
    def __init__(self, initial_clauses=[]):
        self.clauses = [] # inefficient: no indexing
        for clause in initial_clauses:
            self.tell(clause)
    def tell(self, sentence):
        if is_definite_clause(sentence):
            self.clauses.append(sentence)
        else:
            raise Exception("Not a definite clause: {}".format(sentence))
    def ask_generator(self, query):
        q = expr(query)
        test_variables = variables(q)
        answers = fol_bc_ask(self, q)
        return sorted([dict((x, v) for x, v in list(a.items())
                if x in test_variables)
                for a in answers], key=repr)
    def retract(self, sentence):
        self.clauses.remove(sentence)
    def fetch_rules_for_goal(self, goal):
        return self.clauses

test_kb = FolKB(
map(expr, ['LakiLaki(James1)',
           'LakiLaki(Charles)',
           'LakiLaki(Charles1)',
           'LakiLaki(CharlesII)',
           'LakiLaki(JamesII)',
           'LakiLaki(Phillip)',
           'LakiLaki(Mark)',
           'LakiLaki(Andrew)',
           'LakiLaki(Edward)',
           'LakiLaki(William)',
           'LakiLaki(Hendry)',
           'LakiLaki(Peter)',
           'Perempuan(Margareth)',
           'Perempuan(Sophia)',
           'Perempuan(Catherine1)',
           'Perempuan(Elizabeth)',
           'Perempuan(Camila)',
           'Perempuan(Diana)',
           'Perempuan(CatherineII)',
           'Perempuan(Anne)',
           'Perempuan(Zara)',
           'Perempuan(Sarah)',
           'Perempuan(Beatrice)',
           'Perempuan(Eugenie)',
           'Perempuan(Sophie)',
           'Perempuan(Lady)',
           'OrangTua(James1, Charles1)',
           'OrangTua(James1, Elizabeth)',
           'OrangTua(Margareth, Charles1)',
           'OrangTua(Margareth, Elizabeth)',
           'OrangTua(Charles1, Chatherine1)',
           'OrangTua(Charles1, CharlesII)',
           'OrangTua(Charles1, JamesII)',
           'OrangTua(Sophia, Chatherine1)',
           'OrangTua(Sophia, CharlesII)',
           'OrangTua(Sophia, JamesII)',
           'OrangTua(Elizabeth, Charles)',
           'OrangTua(Elizabeth, Anne)',
           'OrangTua(Elizabeth, Andrew)',
           'OrangTua(Elizabeth, Edward)',
           'OrangTua(Phillip, Charles)',
           'OrangTua(Phillip, Anne)',
           'OrangTua(Phillip, Andrew)',
           'OrangTua(Phillip, Edward)',
           'OrangTua(Charles, William)',
           'OrangTua(Charles, Hendry)',
           'OrangTua(Diana, William)',
           'OrangTua(Diana, Hendry)',
           'OrangTua(Anne, Peter)',
           'OrangTua(Anne, Zara)',
           'OrangTua(Mark, Peter)',
           'OrangTua(Mark, Zara)',
           'OrangTua(Andrew, Beatrice)',
           'OrangTua(Andrew, Eugenie)',
           'OrangTua(Sarah, Beatrice)',
           'OrangTua(Sarah, Eugenie)',
           'OrangTua(Edward, Lady)',
           'OrangTua(Sophie, Lady)',
           'IbuTiri(Camila, William)',
           'IbuTiri(Camila, Hendry)',
           'Menikah(James1, Margareth)',
           'Menikah(Charles1, Sophia)',
           'Menikah(Elizabeth, Phillip)',
           'Menikah(Charles, Diana)',
           'Menikah(Charles, Camila)',
           'Menikah(William, CarherineII)',
           'Menikah(Anne, Mark)',
           'Menikah(Andrew, Sarah)',
           'Menikah(Edward, Sophie)',
           '(OrangTua(m,x) & Perempuan(m)) ==> Ibu(m,x)',
           '(OrangTua(f,x) & LakiLaki(f)) ==> Ayah(f,x)',
           '(OrangTua(p,x) & OrangTua(p,y) & LakiLaki(p)) ==> SaudaraKandung(x,y)',
           '(SaudaraKandung(x,y) & Perempuan(x)) ==> KakakPerempuan(x,y)',
           '(SaudaraKandung(x,y) & LakiLaki(x)) ==> KakakLakiLaki(x,y)',
           '(OrangTua(x,y) & SaudaraKandung(x,w) & Perempuan(w)) ==> TanteKandung(w,y)',
           '(OrangTua(x,y) & SaudaraKandung(x,t) & Menikah(t,z) & Perempuan(z)) ==> Tante(z,y)',
           '(OrangTua(x,y) & SaudaraKandung(x,t) & Menikah(t,z) & LakiLaki(z)) ==> Paman(z,y)',
           '(OrangTua(x,y) & OrangTua(e,x) & SaudaraKandung(g,e) & OrangTua(g,a) & Perempuan(a)) ==> TanteSepupu(a)',
           '(OrangTua(x,y) & OrangTua(w,x) & OrangTua(z,w) & LakiLaki(z)) ==> KakekBuyut(z)',
           '(OrangTua(x,y) & OrangTua(w,x) & OrangTua(z,w) & Perempuan(z)) ==> NenekBuyut(z,y)',
           '(OrangTua(x,y) & OrangTua(w,x) & LakiLaki(w)) ==> Kakek(w,y)',
           '(OrangTua(x,y) & OrangTua(w,x) & Perempuan(w)) ==> Nenek(w,y)',
           '(OrangTua(x,y) & OrangTua(p,t) & SaudaraKandung(x,p)) ==> Sepupu(t,y)',
           '(OrangTua(x,y) & OrangTua(w,x) & OrangTua(z,w)) ==> Cicit(y)',
           '(OrangTua(x,y) & OrangTua(w,x) & OrangTua(z,w) & Perempuan(y)) ==> CicitPerempuan(y,z)']))


print(repr(test_kb.ask_generator('Ayah(George1,Charles1)')))
print(repr(test_kb.ask_generator('Ayah(y,Charles1)')))
print(repr(test_kb.ask_generator('Ibu(y,Hendry)')))
print(repr(test_kb.ask_generator('OrangTua(Charles,y)')))
print(repr(test_kb.ask_generator('Paman(Andrew, William)')))
print(repr(test_kb.ask_generator('Tante(y,Peter)')))
print(repr(test_kb.ask_generator('Sepupu(y,Zara)')))
print(repr(test_kb.ask_generator('Nenek(y,William)')))
print(repr(test_kb.ask_generator('(Nenek(Elizabeth,Hendry) and Nenek(Elizabeth,William))')))
print(repr(test_kb.ask_generator('Kakek(y,Peter)')))
print(repr(test_kb.ask_generator('IbuTiri(y, William)')))
print(repr(test_kb.ask_generator('KakakLakiLaki(y, Diana)')))
print(repr(test_kb.ask_generator('KakakPerempuan(y, Andrew)')))
print(repr(test_kb.ask_generator('KakakLakiLaki(y, Andrew)')))
print(repr(test_kb.ask_generator('KakakLakiLaki(y, JamesII)')))
print(repr(test_kb.ask_generator('Tante(Sarah, Peter)')))
print(repr(test_kb.ask_generator('NenekBuyut(y, Hendry)')))
print(repr(test_kb.ask_generator('Paman(y, Charles)')))
print(repr(test_kb.ask_generator('Ibu(Diana, Hendry)')))
print(repr(test_kb.ask_generator('Sepupu(y, Hendry)')))
print(repr(test_kb.ask_generator('CicitPerempuan(y, Elizabeth)')))
